package com.nestedvariables.dev.Discord.Quiver.events.owner;

import com.nestedvariables.dev.Discord.Quiver.Quiver;
import com.nestedvariables.dev.Discord.Quiver.util.Data;
import com.nestedvariables.dev.Discord.Quiver.util.Logger;

import net.dv8tion.jda.core.entities.Guild;
import net.dv8tion.jda.core.events.ReadyEvent;
import net.dv8tion.jda.core.events.guild.GuildJoinEvent;
import net.dv8tion.jda.core.events.guild.member.GuildMemberJoinEvent;
import net.dv8tion.jda.core.events.guild.member.GuildMemberLeaveEvent;
import net.dv8tion.jda.core.hooks.ListenerAdapter;

public class StatsUpdate extends ListenerAdapter {

    Data data = new Data();
    Logger logger = new Logger();
    public void onReady(ReadyEvent event) {
        try{
        Integer guildCount = Quiver.shardManager.getGuilds().size();
        Integer shardCount = Quiver.shardManager.getShardsTotal();
        Integer userCount = Quiver.shardManager.getUsers().size();

            // Shard Channel
            Quiver.shardManager.getGuildById("488137783127572491").getVoiceChannelById("489246383140896778").getManager().setName("Shard Count: " + shardCount).queue();
            // User Channel
            Quiver.shardManager.getGuildById("488137783127572491").getVoiceChannelById("489246451181027328").getManager().setName("User Count: " + userCount).queue();
            // Guild Channel
            Quiver.shardManager.getGuildById("488137783127572491").getVoiceChannelById("489246268313436180").getManager().setName("Guild Count: " + guildCount).queue();

        } catch (Exception e) {
            Guild guild = null;
            logger.log(1, e.toString(), guild);
        }

    }

    public void onGuildJoin(GuildJoinEvent event) {
        try{
            Integer guildCount = Quiver.shardManager.getGuilds().size();
            Integer shardCount = Quiver.shardManager.getShardsTotal();
            Integer userCount = Quiver.shardManager.getUsers().size();
    
                // Shard Channel
                Quiver.shardManager.getGuildById("488137783127572491").getVoiceChannelById("489246383140896778").getManager().setName("Shard Count: " + shardCount).queue();
                // User Channel
                Quiver.shardManager.getGuildById("488137783127572491").getVoiceChannelById("489246451181027328").getManager().setName("User Count: " + userCount).queue();
                // Guild Channel
                Quiver.shardManager.getGuildById("488137783127572491").getVoiceChannelById("489246268313436180").getManager().setName("Guild Count: " + guildCount).queue();
    
            } catch (Exception e) {
                logger.log(1, e.toString(), event.getGuild());
            }
    }

    public void onGuildMemberJoin(GuildMemberJoinEvent event){
        
        try{
            Integer guildCount = Quiver.shardManager.getGuilds().size();
            Integer shardCount = Quiver.shardManager.getShardsTotal();
            Integer userCount = Quiver.shardManager.getUsers().size();
    
                // Shard Channel
                Quiver.shardManager.getGuildById("488137783127572491").getVoiceChannelById("489246383140896778").getManager().setName("Shard Count: " + shardCount).queue();
                // User Channel
                Quiver.shardManager.getGuildById("488137783127572491").getVoiceChannelById("489246451181027328").getManager().setName("User Count: " + userCount).queue();
                // Guild Channel
                Quiver.shardManager.getGuildById("488137783127572491").getVoiceChannelById("489246268313436180").getManager().setName("Guild Count: " + guildCount).queue();
    
            } catch (Exception e) {
                logger.log(1, e.toString(), event.getGuild());
            }
    }

    public void onGuildMemberLeave(GuildMemberLeaveEvent event){
        
        try{
            Integer guildCount = Quiver.shardManager.getGuilds().size();
            Integer shardCount = Quiver.shardManager.getShardsTotal();
            Integer userCount = Quiver.shardManager.getUsers().size();
    
                // Shard Channel
                Quiver.shardManager.getGuildById("488137783127572491").getVoiceChannelById("489246383140896778").getManager().setName("Shard Count: " + shardCount).queue();
                // User Channel
                Quiver.shardManager.getGuildById("488137783127572491").getVoiceChannelById("489246451181027328").getManager().setName("User Count: " + userCount).queue();
                // Guild Channel
                Quiver.shardManager.getGuildById("488137783127572491").getVoiceChannelById("489246268313436180").getManager().setName("Guild Count: " + guildCount).queue();
    
            } catch (Exception e) {
                logger.log(1, e.toString(), event.getGuild());
            }
    }

}