package com.nestedvariables.dev.Discord.Quiver.events.owner;

import com.nestedvariables.dev.Discord.Quiver.Utils;
import com.nestedvariables.dev.Discord.Quiver.util.Data;
import com.nestedvariables.dev.Discord.Quiver.util.Lang;
import com.nestedvariables.dev.Discord.Quiver.util.Logger;

import net.dv8tion.jda.core.EmbedBuilder;
import net.dv8tion.jda.core.events.message.guild.GuildMessageReceivedEvent;
import net.dv8tion.jda.core.hooks.ListenerAdapter;

public class ErrorTest extends ListenerAdapter {

    public void onGuildMessageReceived(GuildMessageReceivedEvent event) {
        String[] args = event.getMessage().getContentRaw().split("\\s+");
        Data data = new Data();
        Lang lang = new Lang();
        Logger logger = new Logger();
        if (args[0].equalsIgnoreCase(data.getPrefix(event.getGuild()) + "error")) {
            try{
            if (Utils.isBotOwner(event.getAuthor())) {
                
                EmbedBuilder error = new EmbedBuilder();

                error.setTitle(lang.getMessage(event.getGuild(), "roleCreateErrorEmbedTitle"));
                error.setDescription(lang.getMessage(event.getGuild(), "roleCreateErrorEmbedDescription"));
                error.setFooter(lang.getMessage(event.getGuild(), "name") + " " + lang.getMessage(event.getGuild(), "roleCreateErrorEmbedFooter"), event.getJDA().getSelfUser().getAvatarUrl());

                event.getChannel().sendMessage(error.build()).queue();
            }
        }catch (Exception e){
            logger.log(1, e.toString(), event.getGuild());
        }

        }
    }
}