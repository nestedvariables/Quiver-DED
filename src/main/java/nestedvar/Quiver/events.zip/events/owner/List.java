package com.nestedvariables.dev.Discord.Quiver.events.owner;

import com.nestedvariables.dev.Discord.Quiver.Utils;
import com.nestedvariables.dev.Discord.Quiver.util.Data;
import com.nestedvariables.dev.Discord.Quiver.util.Lang;

import net.dv8tion.jda.core.EmbedBuilder;
import net.dv8tion.jda.core.events.message.guild.GuildMessageReceivedEvent;
import net.dv8tion.jda.core.hooks.ListenerAdapter;

public class List extends ListenerAdapter {

    public void onGuildMessageReceived(GuildMessageReceivedEvent event) {
        String[] args = event.getMessage().getContentRaw().split("\\s+");
        Data data = new Data();
        Lang lang = new Lang();
        if(args[0].equalsIgnoreCase(data.getPrefix(event.getGuild()) + lang.getMessage(event.getGuild(), "list"))){

            if(args.length < 2) {
                EmbedBuilder nullArgs = new EmbedBuilder();

                nullArgs.setDescription(lang.getMessage(event.getGuild(), "listNullArgsEmbedDescription"));
                nullArgs.setColor(Utils.embedColor("error"));
                nullArgs.setFooter(lang.getMessage(event.getGuild(), "name") + " " + lang.getMessage(event.getGuild(), "listNullArgsEmbedFooter"), Utils.getSelfAvatar(event));

                event.getChannel().sendMessage(nullArgs.build()).queue();
            }
        }
    }
}