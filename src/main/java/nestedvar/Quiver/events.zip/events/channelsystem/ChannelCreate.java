package com.nestedvariables.dev.Discord.Quiver.events.channelsystem;

import java.util.EnumSet;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.nestedvariables.dev.Discord.Quiver.Utils;
import com.nestedvariables.dev.Discord.Quiver.util.Data;
import com.nestedvariables.dev.Discord.Quiver.util.Lang;
import com.nestedvariables.dev.Discord.Quiver.Info;

import net.dv8tion.jda.core.EmbedBuilder;
import net.dv8tion.jda.core.Permission;
import net.dv8tion.jda.core.entities.Category;
import net.dv8tion.jda.core.events.message.guild.GuildMessageReceivedEvent;
import net.dv8tion.jda.core.hooks.ListenerAdapter;

public class ChannelCreate extends ListenerAdapter {

        Boolean nsfwBool;

        public void onGuildMessageReceived(GuildMessageReceivedEvent event) {
                Data data = new Data();
                Lang lang = new Lang();
                String[] args = event.getMessage().getContentRaw().split("\\s+");
                if (args[0].equalsIgnoreCase(
                        data.getPrefix(event.getGuild()) + lang.getMessage(event.getGuild(), "privateChannelCommand"))) {
                        if (Utils.isBlacklisted(event.getAuthor())) {
                                
                                EmbedBuilder blacklist = new EmbedBuilder();
                                blacklist.setDescription(lang.getMessage(event.getGuild(), "blacklistEmbedDescription").replace("{user}", event.getMember().getAsMention()));
                                blacklist.setFooter(lang.getMessage(event.getGuild(), "name") + " " + lang.getMessage(event.getGuild(), "blacklistEmbedFooter"), Utils.getSelfAvatar(event));
                                
                                event.getChannel().sendMessage(blacklist.build()).queue();

                        } else {
                                if (Utils.isChannelSystemEnabled(event.getGuild())) {
                                        if(args.length < 2) {
                                                EmbedBuilder nullArgs = new EmbedBuilder();

                                                nullArgs.setTitle(lang.getMessage(event.getGuild(), "invalidUsage"));
                                                nullArgs.setColor(Info.ERROR_RED);
                                                nullArgs.setDescription(lang.getMessage(event.getGuild(), "channelCreateNullArgsDescription").replace("{prefix}", data.getPrefix(event.getGuild())));
                                                nullArgs.setFooter(lang.getMessage(event.getGuild(), "name") + " " + lang.getMessage(event.getGuild(), "invalidUsage"), Utils.getSelfAvatar(event));

                                                event.getChannel().sendMessage(nullArgs.build()).queue((message) -> {
                                                        message.delete().queueAfter(10, TimeUnit.SECONDS);
                                                });

                                        } else {

                                        Integer slowmodeInt = Integer.parseInt(args[1]);

                                        if (args.toString().contains("-nsfw")) {
                                                nsfwBool = true;
                                        } else {
                                                nsfwBool = false;
                                        }

                                        EnumSet<Permission> pAllow = EnumSet.of(Permission.PRIORITY_SPEAKER, Permission.VOICE_USE_VAD, Permission.VOICE_SPEAK, Permission.VOICE_MUTE_OTHERS, Permission.VOICE_DEAF_OTHERS, Permission.VOICE_CONNECT, Permission.VIEW_CHANNEL, Permission.MESSAGE_ADD_REACTION);
                                        EnumSet<Permission> pTextAllow = EnumSet.of(Permission.MESSAGE_ATTACH_FILES, Permission.MESSAGE_EMBED_LINKS, Permission.MESSAGE_EXT_EMOJI, Permission.MESSAGE_HISTORY, Permission.MESSAGE_MANAGE, Permission.MESSAGE_READ, Permission.MESSAGE_WRITE);
                                        EnumSet<Permission> pDeny = EnumSet.of(Permission.BAN_MEMBERS, Permission.CREATE_INSTANT_INVITE, Permission.KICK_MEMBERS, Permission.MANAGE_CHANNEL, Permission.MANAGE_EMOTES, Permission.MANAGE_PERMISSIONS, Permission.MANAGE_ROLES, Permission.MANAGE_SERVER, Permission.MANAGE_WEBHOOKS);
                                        EnumSet<Permission> pTextDenyEveryone = EnumSet.of(Permission.MESSAGE_ADD_REACTION, Permission.MESSAGE_ATTACH_FILES, Permission.MESSAGE_EMBED_LINKS, Permission.MESSAGE_EXT_EMOJI, Permission.MESSAGE_HISTORY, Permission.MESSAGE_MANAGE, Permission.MESSAGE_MENTION_EVERYONE, Permission.MESSAGE_READ, Permission.MESSAGE_TTS, Permission.MESSAGE_WRITE);
                                        EnumSet<Permission> pVoiceDenyEveryone = EnumSet.of(Permission.PRIORITY_SPEAKER, Permission.VOICE_CONNECT);
                                        List<Category> categoryPrivate = event.getGuild().getCategoriesByName(lang.getMessage(event.getGuild(), "categoryPrivate"), true);
                                        if (categoryPrivate.size() < 1) {
                                                event.getGuild().getController().createCategory(lang.getMessage(event.getGuild(), "categoryPrivate")).queue();
                                                event.getGuild().getController().createTextChannel(lang.getMessage(event.getGuild(), "privateTextChannelName").replace("{channelOwner}", event.getMember().getEffectiveName().toString())).queue((channel) -> {
                                                                        channel.getManager().setParent(event.getGuild().getCategoriesByName(lang.getMessage(event.getGuild(), "categoryPrivate"), true).get(0));
                                                                        channel.getManager().setTopic(lang.getMessage(event.getGuild(), "privateTextChannelTopic").replace("{channelOwner}", event.getMember().getEffectiveName().toString()).replace("{prefix}", data.getPrefix(event.getGuild())));
                                                                        channel.getManager().setSlowmode(slowmodeInt); 
                                                                        channel.getManager().setNSFW(nsfwBool);
                                                                        channel.getManager().putPermissionOverride(event.getMember(), pTextAllow, pDeny).queue();
                                                                        channel.getManager().putPermissionOverride(event.getGuild().getPublicRole(), null, pTextDenyEveryone).queue();
                                                                });
                                                event.getGuild().getController().createVoiceChannel(lang.getMessage(event.getGuild(), "privateVoiceChannelName").replace("{channelOwner}", event.getMember().getEffectiveName().toString())).queue((channel) -> {
                                                                        channel.getManager().setParent(event.getGuild().getCategoriesByName(lang.getMessage(event.getGuild(), "categoryPrivate"), true).get(0));
                                                                        channel.getManager().setUserLimit(1);
                                                                        channel.getManager().putPermissionOverride(event.getMember(), pAllow, pDeny).queue();
                                                                        channel.getManager().putPermissionOverride(event.getGuild().getPublicRole(), null, pVoiceDenyEveryone).queue();
                                                                });
                                        } else {
                                                event.getGuild().getController().createTextChannel(lang.getMessage(event.getGuild(), "privateTextChannelName").replace("{channelOwner}", event.getMember().getEffectiveName().toString())).queue((channel) -> {
                                                                        channel.getManager().setParent(event.getGuild().getCategoriesByName(lang.getMessage(event.getGuild(), "categoryPrivate"), true).get(0));
                                                                        channel.getManager().setTopic(lang.getMessage(event.getGuild(), "privateTextChannelTopic").replace("{channelOwner}", event.getMember().getEffectiveName().toString()).replace("{prefix}", data.getPrefix(event.getGuild())));
                                                                        channel.getManager().setSlowmode(slowmodeInt); 
                                                                        channel.getManager().setNSFW(nsfwBool);
                                                                        channel.getManager().putPermissionOverride(event.getMember(), pTextAllow, pDeny).queue();
                                                                        channel.getManager().putPermissionOverride(event.getGuild().getPublicRole(), null, pTextDenyEveryone).queue();
                                                });
                                                event.getGuild().getController().createVoiceChannel(lang.getMessage(event.getGuild(), "privateVoiceChannelName").replace("{channelOwner}", event.getMember().getEffectiveName().toString())).queue((channel) -> {
                                                                        channel.getManager().setParent(event.getGuild().getCategoriesByName(lang.getMessage(event.getGuild(), "categoryPrivate"), true).get(0));
                                                                        channel.getManager().setUserLimit(1);
                                                                        channel.getManager().putPermissionOverride(event.getMember(), pAllow, pDeny).queue();
                                                                        channel.getManager().putPermissionOverride(event.getGuild().getPublicRole(), null, pVoiceDenyEveryone).queue();
                                                });
                                }
                         }
                } else {
                                        EmbedBuilder disSys = new EmbedBuilder();
                                        
                                        disSys.setColor(Utils.embedColor("error"));
                                        disSys.setDescription(lang.getMessage(event.getGuild(), "disabledPrivateChannels").replace("{user}", event.getMember().getAsMention()));
                                        disSys.setFooter(lang.getMessage(event.getGuild(), "name") + " " + lang.getMessage(event.getGuild(), "disableSystemErrorEmbedFooter"), Utils.getSelfAvatar(event));

                                        event.getChannel().sendMessage(disSys.build()).queue((message) -> {
                                                message.delete().queueAfter(15, TimeUnit.SECONDS);
                                        });
                                }
                        }
                }
        }
}