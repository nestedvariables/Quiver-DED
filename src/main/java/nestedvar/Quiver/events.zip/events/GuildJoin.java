package com.nestedvariables.dev.Discord.Quiver.events;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import com.nestedvariables.dev.Discord.Quiver.util.Data;
import com.nestedvariables.dev.Discord.Quiver.util.Embeds;
import com.nestedvariables.dev.Discord.Quiver.util.Lang;
import com.nestedvariables.dev.Discord.Quiver.util.Logger;
import com.nestedvariables.dev.Discord.Quiver.SQLDriver;

import net.dv8tion.jda.core.EmbedBuilder;
import net.dv8tion.jda.core.Permission;
import net.dv8tion.jda.core.events.guild.GuildJoinEvent;
import net.dv8tion.jda.core.hooks.ListenerAdapter;

public class GuildJoin extends ListenerAdapter {
    public void onGuildJoin(GuildJoinEvent event) {
        Embeds embed = new Embeds();
        Data data = new Data();
        Lang lang = new Lang();
        
        // Send welcome embed in default channel
        embed.joinWelcome(event);

        try {
            if (event.getGuild().getSelfMember().hasPermission(Permission.MANAGE_ROLES)) {
                event.getGuild().getController().createRole().setName(lang.getMessage(event.getGuild(), "premiumRoleName")).setColor(0xfc2525).setMentionable(false).reason("Role for Quiver Premium Users").queue();
            } else {

                EmbedBuilder error = new EmbedBuilder();

                error.setTitle(lang.getMessage(event.getGuild(), "roleCreateErrorEmbedTitle"));
                error.setDescription(lang.getMessage(event.getGuild(), "roleCreateErrorEmbedDescription"));
                error.setFooter(lang.getMessage(event.getGuild(), "name") + lang.getMessage(event.getGuild(), "roleCreateErrorEmbedFooter"), event.getJDA().getSelfUser().getAvatarUrl());

                event.getGuild().getOwner().getUser().openPrivateChannel().queue((channel) -> {
                    channel.sendMessage(error.build()).queue();
                });
            }
        } catch (Exception e) {
            Logger logger = new Logger();
            logger.log(1, e.toString(), event.getGuild());
        }

        try {
            Connection connection = SQLDriver.getConn();
            Statement statement = connection.createStatement();
            ResultSet result = statement
                    .executeQuery("SELECT * FROM `guild_options` WHERE `guild_id`='" + event.getGuild().getId() + "'");

            if (result.next() == false) {
                statement.execute(
                        "INSERT INTO `guild_options`(`guild_id`, `guild_name`, `guild_lang`,`prefix`,`channel_system`) VALUES('"
                                + event.getGuild().getId().toString() + "','" + event.getGuild().getName().toString()
                                + "','" + data.getDefaultLocale(event.getGuild()) + "','Q!','true')");
                System.out.println("Added Guild: " + event.getGuild().getName() + " with ID: "
                        + event.getGuild().getId() + " to the database");
                connection.close();
            } else {
                System.out.println(event.getGuild().getName() + " with ID: " + event.getGuild().getId()
                        + " already exist in database.");
                connection.close();
            }
        } catch (Exception e) {
            Logger logger = new Logger();
            logger.log(1, e.toString(), event.getGuild());
        }
    }
}