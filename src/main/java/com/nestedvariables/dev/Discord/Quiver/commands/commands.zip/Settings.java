package com.nestedvariables.dev.Discord.Quiver.commands;

import com.nestedvariables.dev.Discord.Quiver.Utils;
import com.nestedvariables.dev.Discord.Quiver.util.Data;
import com.nestedvariables.dev.Discord.Quiver.util.Lang;

import net.dv8tion.jda.core.EmbedBuilder;
import net.dv8tion.jda.core.events.message.guild.GuildMessageReceivedEvent;
import net.dv8tion.jda.core.hooks.ListenerAdapter;

public class Settings extends ListenerAdapter {
    public void onGuildMessageReceived(GuildMessageReceivedEvent event) {
        String[] args = event.getMessage().getContentRaw().split("\\s+");

        Data data = new Data();
        Lang lang = new Lang();
        if (args[0].equalsIgnoreCase(data.getPrefix(event.getGuild()) + "set")) {
            if (args.length < 2) {
                EmbedBuilder usage = new EmbedBuilder();
                usage.setTitle(lang.getMessage(event.getGuild(), "usageEmbedTitle").replace("{command}", args[0].replace(data.getPrefix(event.getGuild()), "")).replace("{prefix}", data.getPrefix(event.getGuild())));
                usage.setDescription(lang.getMessage(event.getGuild(), "setUsage").replace("{prefix}", data.getPrefix(event.getGuild())));
                usage.setFooter(lang.getMessage(event.getGuild(), "name") + " " + lang.getMessage(event.getGuild(), "usageEmbedFooter"), event.getJDA().getSelfUser().getAvatarUrl());
                usage.setColor(Utils.embedColor("warning"));
                event.getChannel().sendMessage(usage.build()).queue();
                usage.clear();
            }
            else if (args[1].equalsIgnoreCase(lang.getMessage(event.getGuild(), "prefixSubcommand"))) {
                if (args.length < 3) {
                    EmbedBuilder usage = new EmbedBuilder();
                    usage.setTitle(lang.getMessage(event.getGuild(), "usageEmbedTitle").replace("{command}", args[1].replace(data.getPrefix(event.getGuild()), "")).replace("{prefix}", data.getPrefix(event.getGuild())));
                    usage.setDescription(lang.getMessage(event.getGuild(), "prefixUsage").replace("{prefix}", data.getPrefix(event.getGuild())));
                    usage.setFooter(lang.getMessage(event.getGuild(), "name") + " " + lang.getMessage(event.getGuild(), "usageEmbedFooter"), event.getJDA().getSelfUser().getAvatarUrl());
                    usage.setColor(Utils.embedColor("warning"));
                    event.getChannel().sendMessage(usage.build()).queue();
                    usage.clear();
                }
                else {
                    data.setPrefix(event.getGuild(), args[2]);
                    EmbedBuilder success = new EmbedBuilder();
                    success.setTitle(lang.getMessage(event.getGuild(), "prefixSetEmbedTitle").replace("{prefix}", data.getPrefix(event.getGuild())));
                    success.setDescription(lang.getMessage(event.getGuild(), "prefixSetEmbedDescription").replace("{prefix}", data.getPrefix(event.getGuild())));
                    success.setColor(Utils.embedColor("success"));
                    success.setFooter(lang.getMessage(event.getGuild(), "name") + " " + lang.getMessage(event.getGuild(), "prefixSetEmbedFooter"), event.getJDA().getSelfUser().getAvatarUrl());
                    event.getChannel().sendMessage(success.build()).queue();
                    success.clear();
                }   
            }
            else if (args[1].equalsIgnoreCase(lang.getMessage(event.getGuild(), "localeSubcommand"))) {
                if (args.length < 3) {
                    EmbedBuilder usage = new EmbedBuilder();
                    usage.setTitle(lang.getMessage(event.getGuild(), "usageEmbedTitle").replace("{command}", args[1].replace(data.getPrefix(event.getGuild()), "")).replace("{prefix}", data.getPrefix(event.getGuild())));
                    usage.setDescription(lang.getMessage(event.getGuild(), "localeUsage").replace("{prefix}", data.getPrefix(event.getGuild())));
                    usage.setFooter(lang.getMessage(event.getGuild(), "name") + " " + lang.getMessage(event.getGuild(), "usageEmbedFooter"), event.getJDA().getSelfUser().getAvatarUrl());
                    usage.setColor(Utils.embedColor("warning"));
                    usage.addField("🇧🇷 " + lang.getMessage(event.getGuild(), "brazil"), "`pt_BR`", true);
                    usage.addField("🇪🇺 " + lang.getMessage(event.getGuild(), "europe"), "`en_GB`, `de_DE`", true);
                    usage.addField("🇭🇰 " + lang.getMessage(event.getGuild(), "hongKong"), "`en_HK`", true);
                    usage.addField("🇯🇵 " + lang.getMessage(event.getGuild(), "japan"), "`ja_JP`", true);
                    usage.addField("🇷🇺 " + lang.getMessage(event.getGuild(), "russia"), "`ru_RU`", true);
                    usage.addField("🇸🇬 " + lang.getMessage(event.getGuild(), "singapore"), "`en_SG`", true);
                    usage.addField("🇿🇦 " + lang.getMessage(event.getGuild(), "southAfrica"), "`en_ZA`", true);
                    usage.addField("🇦🇺 " + lang.getMessage(event.getGuild(), "australia"), "`en_AU`", true);
                    usage.addField("🇺🇸 " + lang.getMessage(event.getGuild(), "unitedStates"), "`en_US`", true);
                    event.getChannel().sendMessage(usage.build()).queue();
                    usage.clear();
                }
                else {
                    data.setLocale(event.getGuild(), args[2]);
                    EmbedBuilder success = new EmbedBuilder();
                    success.setTitle(lang.getMessage(event.getGuild(), "localeSetEmbedTitle").replace("{locale}", data.getLocale(event.getGuild())));
                    success.setDescription(lang.getMessage(event.getGuild(), "localeSetEmbedDescription"));
                    success.setColor(Utils.embedColor("success"));
                    success.setFooter(lang.getMessage(event.getGuild(), "name") + " " + lang.getMessage(event.getGuild(), "localeSetEmbedFooter"), event.getJDA().getSelfUser().getAvatarUrl());
                    event.getChannel().sendMessage(success.build()).queue();
                    success.clear();
                }   
            }
        }
    }
}