package com.nestedvariables.dev.Discord.Quiver.commands;

import java.util.concurrent.TimeUnit;
import com.nestedvariables.dev.Discord.Quiver.Utils;
import com.nestedvariables.dev.Discord.Quiver.util.Data;
import com.nestedvariables.dev.Discord.Quiver.util.Lang;
import com.nestedvariables.dev.Discord.Quiver.util.Logger;

import net.dv8tion.jda.core.EmbedBuilder;
import net.dv8tion.jda.core.events.message.guild.GuildMessageReceivedEvent;
import net.dv8tion.jda.core.hooks.ListenerAdapter;

public class Help extends ListenerAdapter {
    public void onGuildMessageReceived(GuildMessageReceivedEvent event) {
        String[] args = event.getMessage().getContentRaw().split("\\s+");

        Data data = new Data();
        Lang lang = new Lang();
        if (args[0].equalsIgnoreCase(data.getPrefix(event.getGuild()) + lang.getMessage(event.getGuild(), "helpCommand")) || args[0].equalsIgnoreCase("q!help")) {
        
            try {
                if (Utils.isBlacklisted(event.getAuthor())) {

                    EmbedBuilder blacklisted = new EmbedBuilder();

                    blacklisted.setDescription(lang.getMessage(event.getGuild(), "blacklistEmbedDescription")
                            .replace("{user}", event.getMember().getAsMention()));
                    blacklisted.setColor(Utils.embedColor("error"));
                    blacklisted.setFooter(
                            lang.getMessage(event.getGuild(), "name") + " "
                                    + lang.getMessage(event.getGuild(), "blacklistEmbedFooter"),
                            event.getJDA().getSelfUser().getAvatarUrl());

                    event.getChannel().sendMessage(blacklisted.build()).queue((message) -> {
                        message.delete().queueAfter(15, TimeUnit.SECONDS);
                    });

                } else if (Utils.isBotOwner(event.getAuthor())) {

                    EmbedBuilder botOwner = new EmbedBuilder();

                    botOwner.setTitle(lang.getMessage(event.getGuild(), "name") + " " + lang.getMessage(event.getGuild(), "botOwnerHelpEmbedTitle")); 
                    botOwner.addField(data.getPrefix(event.getGuild()) + lang.getMessage(event.getGuild(), "helpEmbedAnnounceTitle"), lang.getMessage(event.getGuild(), "helpEmbedAnnounceDescription").replace("{prefix}", data.getPrefix(event.getGuild())), true);
                    botOwner.addField(data.getPrefix(event.getGuild()) + lang.getMessage(event.getGuild(), "helpEmbedBlacklistTitle"), lang.getMessage(event.getGuild(), "helpEmbedBlacklistDescription").replace("{prefix}", data.getPrefix(event.getGuild())), true);
                    botOwner.addField(data.getPrefix(event.getGuild()) + lang.getMessage(event.getGuild(), "helpEmbedUnblackTitle"), lang.getMessage(event.getGuild(), "helpEmbedUnblacklistDescription").replace("{prefix}", data.getPrefix(event.getGuild())), true);
                    botOwner.setFooter(lang.getMessage(event.getGuild(), "name") + " " + lang.getMessage(event.getGuild(), "botOwnerHelpEmbedFooter"), event.getJDA().getSelfUser().getAvatarUrl());
                    
                    event.getChannel().sendMessage(botOwner.build()).queue();

                } else if (Utils.isServerOwner(event)) {

                    EmbedBuilder serverOwner = new EmbedBuilder();

                    serverOwner.setTitle(lang.getMessage(event.getGuild(), "serverOwnerHelpEmbedTitle"));
                    serverOwner.addField(data.getPrefix(event.getGuild()) + lang.getMessage(event.getGuild(), ""), "",
                            true);

                } else if (Utils.isAdministrator(event)) {

                }

            } catch (Exception e) {
                Logger logger = new Logger();
                logger.log(1, e.toString(), event.getGuild());
            }

        }

    }
}